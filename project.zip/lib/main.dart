import 'package:flutter/material.dart'; //Import các Widgets và class từ Flutter Material Design để xây dựng giao diện người dùng.
import 'package:intl/intl.dart'; // Import thư viện intl để định dạng ngày giờ
import 'package:shared_preferences/shared_preferences.dart'; // Import thư viện shared_preferences để lưu trữ dữ liệu trên thiết bị.

//Share preferences là một cách để lưu trữ dữ liệu cục bộ, thường được sử dụng để lưu trữ các giá trị nhỏ mà muốn giữ lại sau khi người dùng thoát khỏi ứng dụng và khởi động lại.
//Trước khi sử dụng cần thêm thư viện vào trong file pubspect.yaml
//Dùng để lưu những tập dữ liệu nhỏ dưới dạng key-value

//Hàm main khởi chạy ứng dụng Flutter bằng cách gọi runApp() và truyền widget TodoApp() vào đó.
void main() {
  runApp(TodoApp());
}

// TodoApp là một StatelessWidget và trả về MaterialApp, cấu hình tiêu đề của ứng dụng là 'Todo List App', home là widget TodoList().
class TodoApp extends StatelessWidget {
  @override //ghi đè phương thức (method) từ lớp cha, dùng để định nghĩa lại phương thức của lớp cha
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quản lý công việc',
      debugShowCheckedModeBanner:
          false, //Xóa biểu tượng Debug Banner ở góc trên bên phải của ứng dụng
      home: TodoList(),
    );
  }
}

//Là một class đại diện cho một công việc với hai thuộc tính là title (tiêu đề công việc) và dateTime (ngày giờ thực hiện công việc).
class Todo {
  String title;
  DateTime dateTime;

  Todo({
    //dùng để chỉ định rằng cả title và dateTime là bắt buộc khi tạo một đối tượng Todo
    required this.title,
    required this.dateTime,
  });
}

//Định nghĩa TodoList là StatefulWidget và tạo ra TodoListState để quản lý trạng thái của nó.
//Trạng thái của TodoList bao gồm danh sách todos (mảng các công việc) và todoController để quản lý TextField nhập công việc mới.
//Flutter sẽ gọi createState() để tạo ra một thể hiện của _TodoListState. Class _TodoListState sẽ quản lý trạng thái của TodoList và cập nhật giao diện người dùng tương ứng khi trạng thái thay đổi.
class TodoList extends StatefulWidget {
  @override
  _TodoListState createState() => _TodoListState();
}

//quản lý trạng thái và cập nhật giao diện người dùng (UI) của TodoList
class _TodoListState extends State<TodoList> {
  List<Todo> todos =
      []; //gọi danh sách công việc đã được định nghĩa ở lớp "Todo"
  TextEditingController todoController = TextEditingController();
  // controller để quản lý dữ liệu nhập liệu từ người dùng. Được sử dụng để nhận và xử lý dữ liệu nhập từ TextField để thêm công việc mới.
  late SharedPreferences sharedPreferences;

  @override
//Trong hàm initState(), loadTodoList() được gọi để tải danh sách công việc từ SharedPreferences khi ứng dụng được khởi chạy.
  void initState() {
    super.initState(); //gọi initState của lớp cha
    loadTodoList();
  }

//Tải danh sách công việc từ SharedPreferences và chuyển đổi từ danh sách chuỗi sang danh sách công việc.
//async, cho phép nó sử dụng await để đợi kết quả từ một hàm có thể chạy bất đồng bộ.
  void loadTodoList() async {
    sharedPreferences = await SharedPreferences
        .getInstance(); //Dùng  SharedPreferences để có thể lưu trữ dữ liệu với các cặp khóa-giá trị.
    setState(() {
      //Cập nhật trạng thái của widget
      List<String>? todoStrings = sharedPreferences.getStringList(
          'todos'); //Đọc danh sách công việc từ SharedPreferences dựa trên khóa 'todos', trả về danh sách các chuỗi hoặc null nếu không có dữ liệu.
      if (todoStrings != null) {
        //kiểm tra danh sách công việc có dữ liệu hay không
        todos = todoStrings
            .map((todoString) => Todo(
                  //Sử dụng map để chuyển đổi từ danh sách chuỗi sang danh sách các đối tượng Todo.
                  title: todoString.split('::')[
                      0], //Tách chuỗi để lấy tiêu đề của công việc từ chuỗi lưu trữ.
                  dateTime: DateTime.parse(todoString.split('::')[
                      1]), //Phân tích chuỗi thời gian thành đối tượng DateTime để lưu thời gian của công việc.
                ))
            .toList();
      }
    });
  }

//Thêm một công việc mới vào danh sách với ngày giờ hiện tại và lưu lại danh sách công việc
  void addTodo() {
    setState(() {
      //cập nhật trạng thái widget
      todos.add(Todo(
        title: todoController.text, //tiêu đề công việc do người dùng nhập
        dateTime: DateTime.now(), //thời gian hiện tại
      ));
      todoController
          .clear(); //Xóa nội dung trong todoController sau khi công việc được thêm vào danh sách
      saveTodoList(); //để lưu trạng thái mới của danh sách todos vào SharedPreferences.
    });
  }

//Xóa một công việc khỏi danh sách và lưu lại danh sách công việc.
  void removeTodo(int index) {
    setState(() {
      todos.removeAt(index);
      saveTodoList();
    });
  }

//hàm saveTodoList() tạo ra một danh sách các chuỗi từ danh sách todos, mỗi chuỗi đại diện cho một công việc cụ thể với định dạng "title::dateTime".
//Dùng map để chuyển đổi từ danh sách các đối tượng Todo sang danh sách các chuỗi.
  void saveTodoList() {
    List<String> todoStrings = todos
        .map((todo) =>
            '${todo.title}::${DateFormat('yyyy-MM-dd HH:mm:ss').format(todo.dateTime)}')
        .toList();
    sharedPreferences.setStringList('todos', todoStrings);
  }

  @override
  //Tạo giao diện chính của app
  //Scaffold là một cấu trúc giao diện cơ bản trong Flutter, cung cấp các thành phần chung như thanh tiêu đề, thân ứng dụng và nhiều thành phần khác.
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        //Thuộc tính của Scaffold, tạo tiêu đề ứng dụng
        title: Text('Danh sách công việc'),
      ),
      body: ListView.builder(
        //listview tạo ra một danh sách cuộn
        itemCount: todos.length, // xác định số lượng phần tử trong danh sách
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(
                '${todos[index].title} - ${DateFormat('yyyy-MM-dd HH:mm:ss').format(todos[index].dateTime)}'),
            trailing: IconButton(
              //Tạo biểu tượng "xóa" ở bên phải "listtile"
              icon: Icon(Icons.delete),
              onPressed: () => removeTodo(index),
            ),
          );
        },
      ),
      //Tạo nút biểu tượng hình tròn kích hoạt hành động chính trong ứng dụng
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showDialog(
            //hiển thị hộp thoại, gồm một tiêu đề, một trường nhập liệu (TextField) và một nút xác nhận (TextButton).
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                title: Text('Thêm công việc'),
                content: TextField(
                  controller: todoController,
                ),
                actions: [
                  TextButton(
                    child: Text('Xác nhận'),
                    onPressed: () {
                      addTodo();
                      Navigator.of(context).pop(); //đóng hộp thoại
                    },
                  ),
                ],
              );
            },
          );
        },
        child: Icon(Icons.add), //Tạo biểu tượng "+"
      ),
    );
  }
}
